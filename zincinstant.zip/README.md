zinc_instant
============

Buy anything from any online retailer in two clicks.
